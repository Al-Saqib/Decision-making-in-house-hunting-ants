# -*- coding: utf-8 -*-
"""
Created on Thu Nov 23 21:56:11 2023

@author: am2597
"""
import numpy as np

probs = np.array([[0.76, 0.08, 0.08, 0.08], [0.08, 0.82, 0.05, 0.05], [0.08, 0.05, 0.82, 0.05], [0.08, 0.05, 0.05, 0.82]])
print(probs)


time = 100* probs
print(time)