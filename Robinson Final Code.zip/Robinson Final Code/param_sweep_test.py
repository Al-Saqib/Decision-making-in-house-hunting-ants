import numpy as np
import ExampleUsingRobinsonCode_func as ef

means = np.linspace(4, 4, 6, num=11)

returned = []
for m in means:
    returned.append(ef.runIt(m))

print(returned)